'''
Deep Learning Programming Assignment 2
--------------------------------------
Name: Abhipsa Basu
Roll No.: 16CS60R16

======================================
Complete the functions in this file.
Note: Do not change the function signatures of the train
and test functions
'''
from __future__ import absolute_import
from __future__ import division
#from __future__ import print_function

import numpy as np

import argparse
import sys
import random
from tensorflow.examples.tutorials.mnist import input_data

import tensorflow as tf
dnnWeightsPath = "dnn/dnnWeight"


x = tf.placeholder(tf.float32, [None, 784])
y_ = tf.placeholder(tf.float32, [None, 10])
    
W1 = tf.Variable(tf.truncated_normal([784,100],stddev=0.1),name="W1")
b1 = tf.Variable(tf.truncated_normal([100],stddev=0.1),name="b1")

W2 = tf.Variable(tf.truncated_normal([100,100],stddev=0.1),name="W2")
b2 = tf.Variable(tf.truncated_normal([100],stddev=0.1),name="b2")

W3 = tf.Variable(tf.truncated_normal([100,10],stddev=0.1),name="W3")
b3 = tf.Variable(tf.truncated_normal([10],stddev=0.1),name="b3")

h1 = tf.nn.relu(tf.matmul(x,W1) + b1)
h2 = tf.nn.sigmoid(tf.matmul(h1,W2) + b2)
y = tf.nn.softmax(tf.matmul(h2, W3) + b3)
cross_entropy = tf.reduce_mean(
  	tf.nn.softmax_cross_entropy_with_logits(labels=y_, logits=y))
train_step = tf.train.AdamOptimizer().minimize(cross_entropy)
#    batch_size=100
correct_prediction = tf.equal(tf.argmax(y, 1), tf.argmax(y_, 1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))


def train(trainX, trainY):
    trainX = trainX.reshape([-1,784])
    ys = np.array([ np.array([0 for i in range(10)]) for y in range(len(trainY)) ])
    for i in range(len(trainY)):
    	ys[i][trainY[i]] = 1

    #print(trainX.shape, oneHotTrainY.shape)
    '''ys=np.zeros((len(trainY),10),dtype=np.float32)
    for i in range(len(trainY)):
	ys[i][trainY[i]]=1'''
    print(trainX.shape)
    # Create the model
    sess = tf.InteractiveSession()
    tf.global_variables_initializer().run()
    saver = tf.train.Saver()
    #saver.restore(sess, dnnWeightsPath)

    # Train
    for z in range(20):
        sess.run(train_step, feed_dict={x: trainX, y_: ys})
	print(z,sess.run(accuracy, feed_dict={x: trainX, y_: ys}))
	if z%10==0:
		save_path = saver.save(sess, dnnWeightsPath)

    save_path = saver.save(sess, dnnWeightsPath)
    
    print(sess.run(accuracy, feed_dict={x: trainX,
                                      y_: ys}))
def test(testX):
    '''
    Complete this function.
    This function must read the weight files and
    return the predicted labels.
    The returned object must be a 1-dimensional numpy array of
    length equal to the number of examples. The i-th element
    of the array should contain the label of the i-th test
    example.
    '''
    testX = testX.reshape([-1,784])

    sess = tf.InteractiveSession()
    saver = tf.train.Saver()
    saver.restore(sess, dnnWeightsPath)
	# print("Model restored.")

    predictions = sess.run(tf.argmax(y,1), feed_dict={x: testX})
	
    return predictions
